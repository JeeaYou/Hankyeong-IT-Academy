
from flask import Flask

def create_app():
    app = Flask(__name__)
    # 블루프린트
    from .views import main_view,test_view,astigmatism_view,cataract_view, colortest_view,eyetest_view,glaucoma_view,maculopathy_view,game_view,contact_view
    app.register_blueprint(main_view.bp)
    app.register_blueprint(test_view.bp)
    app.register_blueprint(astigmatism_view.bp)
    app.register_blueprint(cataract_view.bp)
    app.register_blueprint(colortest_view.bp)
    app.register_blueprint(eyetest_view.bp)
    app.register_blueprint(glaucoma_view.bp)
    app.register_blueprint(maculopathy_view.bp)

    app.register_blueprint(game_view.bp)
    app.register_blueprint(contact_view.bp)



    return app
# 현재 상황 - mysql에 연동한 후 회원가입 테이블 생성 한 후 회원가입 페이지 만드는 중