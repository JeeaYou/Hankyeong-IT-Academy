from flask import Response, render_template
import cv2
import mediapipe as mp
import datetime
from..static.models import cataract_predict as cp
from PIL import ImageFont, ImageDraw, Image
import pandas as pd
import numpy as np
from ..static.models import eyeTest as et
from flask import Blueprint

bp = Blueprint("eyetest", __name__)

@bp.route("/test/eyetest")
def index():
    return render_template("eyetest.html")

@bp.route('/eyetest')
def eyetest_cam():
    mp_face_detection = mp.solutions.face_detection  # 얼굴 검출
    mp_drawing = mp.solutions.drawing_utils  # 얼굴 특징 표시
    mp_hands = mp.solutions.hands

    width = 1280
    height = 720

    font = ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 40)
    logo = cv2.resize(cv2.imread('eyezoa/static/button/eye.png', cv2.IMREAD_UNCHANGED), (80, 80))
    face = cv2.resize(cv2.imread('eyezoa/static/button/face.png', cv2.IMREAD_UNCHANGED), (80, 80))
    background = cv2.resize(cv2.imread('eyezoa/static/button/background.jpg'), (1000, 630))

    def text_def(xy, text_name, fontstyle, text_color):
        global image
        image = Image.fromarray(image)
        draw = ImageDraw.Draw(image)
        draw.text(xy=xy, text=text_name, font=fontstyle, fill=text_color)
        image = np.array(image)

    List = []
    cap = cv2.VideoCapture(0)

    def generate_frames():
        global image
        testEnd = False
        with mp_face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.7) as face_detection:
            while True:
                if cap.get(cv2.CAP_PROP_POS_FRAMES) == cap.get(cv2.CAP_PROP_FRAME_COUNT):
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
                success, image = cap.read()
                image = cv2.flip(image, 1)

                image.flags.writeable = False
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                results = face_detection.process(image)
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                text_def((100, 35), f'손을 깜빡해주세요~', font, (0, 0, 0))

                if testEnd is False:
                    if results.detections:
                        for detection in results.detections:
                            keypoints = detection.location_data.relative_keypoints
                            right_eye = keypoints[0]  # 왼쪽눈
                            left_eye = keypoints[1]  # 오른쪽눈

                            h, w, _ = image.shape
                            right = image[int(right_eye.y * h - 40):int(right_eye.y * h + 40),
                                    int(right_eye.x * w - 60):int(right_eye.x * w + 40)]
                            left = image[int(left_eye.y * h - 40):int(left_eye.y * h + 40),
                                   int(left_eye.x * w - 40):int(left_eye.x * w + 40)]

                    now = datetime.datetime.now().strftime("%d_%H-%M-%S")
                    right_name = 'eyezoa/static/image_/' + 'right_image' + str(now) + ".jpg"
                    left_name = 'eyezoa/static/image_/' + 'left_image' + str(now) + ".jpg"

                    with mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.5,
                                        min_tracking_confidence=0.5) as hands:
                        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                        results = hands.process(image)
                        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                        if results.multi_hand_landmarks:
                            for hand_landmarks in results.multi_hand_landmarks:
                                finger1 = int(hand_landmarks.landmark[8].y * 100)
                                finger2 = int(hand_landmarks.landmark[5].y * 100)
                                hand = int(hand_landmarks.landmark[0].y * 100)
                                dist = abs(int(finger1 - hand))
                                dist2 = abs(int(finger2 - hand))

                                et.overlay(image, *(450, 130), 40, 40, face)
                                text_def((495, 115), f'정면봐주세요~', font, (0, 225, 225))

                                if dist < dist2:
                                    print("왼쪽 눈")
                                    cv2.imwrite(right_name, right)
                                    class_name, score = cp.image_test(right_name)
                                    score_str = str(score) + '%'
                                    List.append({
                                        '여부': class_name,
                                        '확률': score_str,
                                        '이미지': right_name
                                    })
                                    df = pd.DataFrame(List)
                                    df.to_csv(f'eyezoa/static/csv파일/왼쪽눈.csv')
                                    print(class_name, score_str)
                                    print("오른쪽 눈")

                                    cv2.imwrite(left_name, left)
                                    class_name, score = cp.image_test(left_name)
                                    score_str = str(score) + '%'
                                    List.append({
                                        '여부': class_name,
                                        '확률': score_str,
                                        '이미지': left_name
                                    })
                                    df = pd.DataFrame(List)
                                    df.to_csv(f'eyezoa/static/csv파일/오른쪽눈.csv')
                                    print(class_name, score_str)
                                    print('-' * 50)
                                    testEnd = True
                else:
                    et.img_size(image, background, 630, 360)
                    text_def((320, 220), f"백내장 테스트 결과 ", ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 70), (0, 0, 0))
                    text_def((400, 360), f" 왼 쪽 :          {score_str} {class_name}", font, (0, 0, 0))
                    text_def((400, 480), f"오른쪽 :         {score_str} {class_name}", font, (0, 0, 0))

                    right_img = cv2.resize(cv2.imread(right_name, cv2.IMREAD_UNCHANGED), (80, 80))
                    left_img = cv2.resize(cv2.imread(left_name, cv2.IMREAD_UNCHANGED), (80, 80))
                    et.img_size(image, right_img, 600, 380)
                    et.img_size(image, left_img, 600, 500)

                et.overlay(image, *(50, 50), 40, 40, logo)
                key = cv2.waitKey(1)
                if key == ord('r'):
                    testEnd = False

                elif key == ord('q'):
                    break
                ret, buffer = cv2.imencode('.jpg', image)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        print(List)
        print('저장 완료됬습니다.')

    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

