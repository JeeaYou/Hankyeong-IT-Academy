from flask import Response, render_template
import cv2
from cvzone.FaceMeshModule import FaceMeshDetector
import mediapipe as mp
import numpy as np
from PIL import ImageFont, ImageDraw, Image
import pandas as pd
import datetime
import time
from ..static.models import eyeTest as et
from flask import Blueprint

bp = Blueprint("colortest", __name__)

@bp.route("/test/colortest")
def index():
    return render_template("colortest.html")

@bp.route('/colortest')
def colortest_cam():
    disease_name = '색맹'
    now = datetime.datetime.now()
    nowDatetime = now.strftime('%Y-%m-%d %H:%M:%S')

    detector = FaceMeshDetector(maxFaces=1)
    mp_hands = mp.solutions.hands

    width = 1260
    height = 720

    counter = 0
    selectionSpeed = 8
    btn_size = 40
    List = []
    num = []
    timeStart = time.time()

    font = ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 40)
    true = cv2.resize(cv2.imread('eyezoa/static/button/Yes.png', cv2.IMREAD_UNCHANGED), (80, 80))
    false = cv2.resize(cv2.imread('eyezoa/static/button/No.png', cv2.IMREAD_UNCHANGED), (80, 80))
    logo = cv2.resize(cv2.imread('eyezoa/static/button/eye.png', cv2.IMREAD_UNCHANGED), (80, 80))
    background = cv2.resize(cv2.imread('eyezoa/static/image/background.jpg'), (1000, 630))
    disease = cv2.resize(cv2.imread('eyezoa/static/image/colortest/colortest.jpg'), (1000, 370))
    test = cv2.resize(cv2.imread('eyezoa/static/image/test.png', cv2.IMREAD_UNCHANGED), (300, 210))

    two = cv2.resize(cv2.imread('eyezoa/static/image/colortest/2.png', cv2.IMREAD_UNCHANGED), (80, 80))
    twentyone = cv2.resize(cv2.imread('eyezoa/static/image/colortest/21.png', cv2.IMREAD_UNCHANGED), (80, 80))
    twentysix = cv2.resize(cv2.imread('eyezoa/static/image/colortest/26.png', cv2.IMREAD_UNCHANGED), (80, 80))
    seventyfour = cv2.resize(cv2.imread('eyezoa/static/image/colortest/74.png', cv2.IMREAD_UNCHANGED), (80, 80))
    nintyseven = cv2.resize(cv2.imread('eyezoa/static/image/colortest/97.png', cv2.IMREAD_UNCHANGED), (80, 80))

    def text_def(xy, text_name, fontstyle, text_color):
        global image
        image = Image.fromarray(image)
        draw = ImageDraw.Draw(image)
        draw.text(xy=xy, text=text_name, font=fontstyle, fill=text_color)
        image = np.array(image)

    cap = cv2.VideoCapture(0)
    def generate_frames():
        global image
        testEnd = False
        another = False
        eye = '오른쪽눈'
        with mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
            while True:
                if cap.get(cv2.CAP_PROP_POS_FRAMES) == cap.get(cv2.CAP_PROP_FRAME_COUNT):
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
                success, image = cap.read()

                image = cv2.flip(image, 1)
                image, faces = detector.findFaceMesh(image, draw=False)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                results = hands.process(image)
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                et.overlay(image, *(210, 550), 40, 40, two)
                et.overlay(image, *(423, 550), 40, 40, twentyone)
                et.overlay(image, *(636, 550), 40, 40, twentysix)
                et.overlay(image, *(849, 550), 40, 40, seventyfour)
                et.overlay(image, *(1060, 550), 40, 40, nintyseven)

                if testEnd is False:
                    if another is False:

                        text_def((100, 35), f'그림을 보고 정답을 찾으세요.', font, (0, 0, 0))
                        et.img_size(image, disease, 630, 300)
                        et.overlay(image, *(50, 50), 40, 40, logo)
                        text_def((150, 130), f"① ", ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 70), (0, 0, 0))
                        text_def((500, 130), f"② ", ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 70), (0, 0, 0))
                        text_def((850, 130), f"③ ", ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 70), (0, 0, 0))

                        if results.multi_hand_landmarks:
                            for hand_landmarks in results.multi_hand_landmarks:
                                finger = hand_landmarks.landmark[8]
                                h, w, _ = image.shape
                                finger = (int(finger.x * w), int(finger.y * h))
                                if len(num) < 3:
                                    if (abs(finger[0] - 210) < btn_size) & (abs(finger[1] - 550) < btn_size):
                                        counter += 1
                                        cv2.ellipse(image, (210, 550), (btn_size, btn_size), 0, 0,
                                                    counter * selectionSpeed, (255, 0, 255), 10)
                                        if counter * selectionSpeed > 360:
                                            counter = 0
                                            answer = 2
                                            num.append(answer)

                                    elif (abs(finger[0] - 423) < btn_size) & (abs(finger[1] - 550) < btn_size):
                                        counter += 1
                                        cv2.ellipse(image, (423, 550), (btn_size, btn_size), 0, 0,
                                                    counter * selectionSpeed, (255, 0, 255), 10)
                                        if counter * selectionSpeed > 360:
                                            counter = 0
                                            answer = 21
                                            num.append(answer)

                                    elif (abs(finger[0] - 636) < btn_size) & (abs(finger[1] - 550) < btn_size):
                                        counter += 1
                                        cv2.ellipse(image, (636, 550), (btn_size, btn_size), 0, 0,
                                                    counter * selectionSpeed, (255, 0, 255), 10)
                                        if counter * selectionSpeed > 360:
                                            counter = 0
                                            answer = 26
                                            num.append(answer)

                                    elif (abs(finger[0] - 849) < btn_size) & (abs(finger[1] - 550) < btn_size):
                                        counter += 1
                                        cv2.ellipse(image, (849, 550), (btn_size, btn_size), 0, 0,
                                                    counter * selectionSpeed, (255, 0, 255), 10)
                                        if counter * selectionSpeed > 360:
                                            counter = 0
                                            answer = 74
                                            num.append(answer)

                                    elif (abs(finger[0] - 1060) < btn_size) & (abs(finger[1] - 550) < btn_size):
                                        counter += 1
                                        cv2.ellipse(image, (1060, 550), (btn_size, btn_size), 0, 0,
                                                    counter * selectionSpeed, (255, 0, 255), 10)
                                        if counter * selectionSpeed > 360:
                                            counter = 0
                                            answer = 97
                                            num.append(answer)
                                    else:
                                        pass

                                elif len(num) == 3:
                                    if (num[0] == 97) & (num[1] == 74) & (num[2] == 26):
                                        final = '정상'
                                    elif (num[1] == 21) & (num[2] != 2):
                                        final = '적녹색맹'
                                    elif ((num[1] == 21) & (num[2] == 2)) | (num[2] == 2):
                                        final = '녹색맹'
                                    else:
                                        final = '색맹'
                                    List.append({
                                        '시간': nowDatetime,
                                        '눈': eye,
                                        '여부': final
                                    })

                                    print(f'{final}입니다')
                                    df = pd.DataFrame(List)
                                    df.to_csv(f'eyezoa/static/csv파일/{disease_name}.csv')

                                    if eye == '오른쪽눈':
                                        timeStart = time.time()
                                        another = True
                                    else:
                                        timeStart = time.time()
                                        testEnd = True

                                cv2.circle(image, finger, 20, (255, 0, 0), 2, cv2.LINE_AA)  # 파란색
                        et.overlay(image, *(150, 630), 150, 120, test)
                        text_def((65, 607), f'{eye}', ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 30), (0, 0, 0))
                    else:
                        et.img_size(image, background, 630, 360)
                        eye = '왼쪽눈'
                        text_def((390, 250), '테스트 계속하기', ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 70),
                                 (0, 0, 0))
                        text_def((350, 380), f'{int(6 - (time.time() - timeStart))}초후 {eye} 테스트 시작합니다.',
                                 ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 40), (0, 0, 0))
                        num = []
                        if int(6 - (time.time() - timeStart)) == 0:
                            another = False

                else:
                    et.img_size(image, background, 630, 360)
                    text_def((370, 220), f"{disease_name}테스트 검사결과 ",
                             ImageFont.truetype('eyezoa/static/fonts/H2GSRB.TTF', 60), (0, 0, 0))
                    text_def((480, 360), f"{List[0]['눈']}: {List[0]['여부']} ", font, (0, 0, 0))
                    text_def((480, 450), f"{List[1]['눈']}: {List[1]['여부']} ", font, (0, 0, 0))

                key = cv2.waitKey(1)
                if key == ord('q'):
                    break

                ret, buffer = cv2.imencode('.jpg', image)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        print(List)
        print('저장 완료됬습니다.')
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

