from flask import Blueprint, render_template

bp = Blueprint("test", __name__, url_prefix='/')

@bp.route("/test")
def index():
    return render_template("test.html")


